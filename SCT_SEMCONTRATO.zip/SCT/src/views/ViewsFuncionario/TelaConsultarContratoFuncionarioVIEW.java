/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.ViewsFuncionario;


import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;



/**
 *
 * @author Maresia-
 */
public class TelaConsultarContratoFuncionarioVIEW extends javax.swing.JFrame {

    
    
    
    public TelaConsultarContratoFuncionarioVIEW() {
        initComponents();
        
        
    }
    
    //////////PARTE Termo de Uso ////////////////////////////////////////
public void setColorBtn(JPanel panel){

    panel.setBackground(new java.awt.Color(0,102,102));
}

public void resetColorBtn(JPanel panel){
 
    panel.setBackground(new java.awt.Color(19,19,70));

}
/////////////////////////////////////////////////////////////////////  
    



   
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        label_Empresa = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        label_PesquisaridContrato = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_Funcionario = new javax.swing.JTable();
        Painel_Cadastrar = new javax.swing.JPanel();
        label_Cadastrar8 = new javax.swing.JLabel();
        Painel_Atualizar = new javax.swing.JPanel();
        label_Cadastrar9 = new javax.swing.JLabel();
        Panel_Menu = new javax.swing.JPanel();
        label_Cadastrar = new javax.swing.JLabel();
        label_CNPJ1 = new javax.swing.JLabel();
        txtIdContrato = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        label_CNPJ = new javax.swing.JLabel();
        ftCPF = new javax.swing.JFormattedTextField();
        jSeparator3 = new javax.swing.JSeparator();
        label_PesquisarCPF = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(19, 19, 70));

        label_Empresa.setBackground(new java.awt.Color(240, 255, 255));
        label_Empresa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa.setForeground(new java.awt.Color(240, 255, 255));
        label_Empresa.setText("CONSULTAR CONTRATO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(label_Empresa)
                .addContainerGap(611, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(label_Empresa)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        jPanel2.setBackground(new java.awt.Color(240, 255, 255));

        label_PesquisaridContrato.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-search-24 (1).png"))); // NOI18N
        label_PesquisaridContrato.setToolTipText("PESQUISAR");
        label_PesquisaridContrato.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_PesquisaridContrato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_PesquisaridContratoMouseClicked(evt);
            }
        });

        tb_Funcionario.setForeground(new java.awt.Color(240, 255, 255));
        tb_Funcionario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tb_Funcionario);

        Painel_Cadastrar.setBackground(new java.awt.Color(19, 19, 70));
        Painel_Cadastrar.setToolTipText("CADASTRAR");
        Painel_Cadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Painel_Cadastrar.setPreferredSize(new java.awt.Dimension(95, 44));
        Painel_Cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Painel_CadastrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Painel_CadastrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Painel_CadastrarMouseExited(evt);
            }
        });

        label_Cadastrar8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        label_Cadastrar8.setForeground(new java.awt.Color(240, 255, 255));
        label_Cadastrar8.setText("CADASTRAR");

        javax.swing.GroupLayout Painel_CadastrarLayout = new javax.swing.GroupLayout(Painel_Cadastrar);
        Painel_Cadastrar.setLayout(Painel_CadastrarLayout);
        Painel_CadastrarLayout.setHorizontalGroup(
            Painel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 124, Short.MAX_VALUE)
            .addGroup(Painel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Painel_CadastrarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar8)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        Painel_CadastrarLayout.setVerticalGroup(
            Painel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Painel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Painel_CadastrarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar8)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        Painel_Atualizar.setBackground(new java.awt.Color(19, 19, 70));
        Painel_Atualizar.setToolTipText("ATUALIZAR");
        Painel_Atualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Painel_Atualizar.setPreferredSize(new java.awt.Dimension(95, 44));
        Painel_Atualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Painel_AtualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Painel_AtualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Painel_AtualizarMouseExited(evt);
            }
        });

        label_Cadastrar9.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        label_Cadastrar9.setForeground(new java.awt.Color(240, 255, 255));
        label_Cadastrar9.setText("ATUALIZAR");

        javax.swing.GroupLayout Painel_AtualizarLayout = new javax.swing.GroupLayout(Painel_Atualizar);
        Painel_Atualizar.setLayout(Painel_AtualizarLayout);
        Painel_AtualizarLayout.setHorizontalGroup(
            Painel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 124, Short.MAX_VALUE)
            .addGroup(Painel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Painel_AtualizarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar9)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        Painel_AtualizarLayout.setVerticalGroup(
            Painel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Painel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Painel_AtualizarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar9)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        Panel_Menu.setBackground(new java.awt.Color(19, 19, 70));
        Panel_Menu.setToolTipText("MENU");
        Panel_Menu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Panel_Menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Panel_MenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Panel_MenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Panel_MenuMouseExited(evt);
            }
        });

        label_Cadastrar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Cadastrar.setForeground(new java.awt.Color(240, 255, 255));
        label_Cadastrar.setText("MENU");

        javax.swing.GroupLayout Panel_MenuLayout = new javax.swing.GroupLayout(Panel_Menu);
        Panel_Menu.setLayout(Panel_MenuLayout);
        Panel_MenuLayout.setHorizontalGroup(
            Panel_MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 124, Short.MAX_VALUE)
            .addGroup(Panel_MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_MenuLayout.createSequentialGroup()
                    .addContainerGap(35, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar)
                    .addContainerGap(35, Short.MAX_VALUE)))
        );
        Panel_MenuLayout.setVerticalGroup(
            Panel_MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Panel_MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_MenuLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        label_CNPJ1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ1.setText("ID CONTRATO");

        txtIdContrato.setBackground(new java.awt.Color(240, 255, 255));
        txtIdContrato.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        txtIdContrato.setToolTipText("NOME DA EMPRESA");
        txtIdContrato.setBorder(null);

        jSeparator1.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator1.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator1.setOpaque(true);

        label_CNPJ.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        label_CNPJ.setText("CPF");

        ftCPF.setBackground(new java.awt.Color(240, 255, 255));
        ftCPF.setBorder(null);
        try {
            ftCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        ftCPF.setToolTipText("CNPJ");

        jSeparator3.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator3.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator3.setOpaque(true);

        label_PesquisarCPF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-search-24 (1).png"))); // NOI18N
        label_PesquisarCPF.setToolTipText("PESQUISAR");
        label_PesquisarCPF.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_PesquisarCPF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_PesquisarCPFMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Panel_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(120, 120, 120)
                        .addComponent(Painel_Atualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(125, 125, 125)
                        .addComponent(Painel_Cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label_CNPJ)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(ftCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(label_PesquisarCPF)))
                        .addGap(176, 176, 176)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtIdContrato)
                            .addComponent(label_CNPJ1)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_PesquisaridContrato))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 617, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(152, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label_PesquisaridContrato)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(label_CNPJ1)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGap(22, 22, 22)
                                    .addComponent(txtIdContrato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(4, 4, 4)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(label_CNPJ)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ftCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label_PesquisarCPF))
                        .addGap(5, 5, 5)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Painel_Cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Panel_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Painel_Atualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(211, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 74, 870, 650));

        setSize(new java.awt.Dimension(855, 599));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void label_PesquisaridContratoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_PesquisaridContratoMouseClicked
     
    }//GEN-LAST:event_label_PesquisaridContratoMouseClicked

    private void Panel_MenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_MenuMouseClicked
         TelaMenuEmpresaVIEW tmev = new TelaMenuEmpresaVIEW();
         tmev.setVisible(true);
         this.dispose();
    }//GEN-LAST:event_Panel_MenuMouseClicked

    private void Panel_MenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_MenuMouseEntered
        setColorBtn(Panel_Menu);
    }//GEN-LAST:event_Panel_MenuMouseEntered

    private void Panel_MenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_MenuMouseExited
        resetColorBtn(Panel_Menu);
    }//GEN-LAST:event_Panel_MenuMouseExited

    private void Painel_AtualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_AtualizarMouseExited
        resetColorBtn(Painel_Atualizar);
    }//GEN-LAST:event_Painel_AtualizarMouseExited

    private void Painel_AtualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_AtualizarMouseEntered
        setColorBtn(Painel_Atualizar);
    }//GEN-LAST:event_Painel_AtualizarMouseEntered

    private void Painel_AtualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_AtualizarMouseClicked
        TelaAtualizarFuncionarioVIEW tafv = new TelaAtualizarFuncionarioVIEW();
        tafv.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Painel_AtualizarMouseClicked

    private void Painel_CadastrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_CadastrarMouseExited
        resetColorBtn(Painel_Cadastrar);
    }//GEN-LAST:event_Painel_CadastrarMouseExited

    private void Painel_CadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_CadastrarMouseEntered
        setColorBtn(Painel_Cadastrar);
    }//GEN-LAST:event_Painel_CadastrarMouseEntered

    private void Painel_CadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_CadastrarMouseClicked
        TelaCadastrarFuncionarioVIEW tcfv = new TelaCadastrarFuncionarioVIEW();
        tcfv.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Painel_CadastrarMouseClicked

    private void label_PesquisarCPFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_PesquisarCPFMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_label_PesquisarCPFMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConsultarContratoFuncionarioVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConsultarContratoFuncionarioVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConsultarContratoFuncionarioVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConsultarContratoFuncionarioVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new TelaConsultarContratoFuncionarioVIEW().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel Painel_Atualizar;
    public javax.swing.JPanel Painel_Cadastrar;
    public javax.swing.JPanel Panel_Menu;
    public javax.swing.JFormattedTextField ftCPF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel label_CNPJ;
    private javax.swing.JLabel label_CNPJ1;
    private javax.swing.JLabel label_Cadastrar;
    private javax.swing.JLabel label_Cadastrar8;
    private javax.swing.JLabel label_Cadastrar9;
    private javax.swing.JLabel label_Empresa;
    public javax.swing.JLabel label_PesquisarCPF;
    public javax.swing.JLabel label_PesquisaridContrato;
    public javax.swing.JTable tb_Funcionario;
    public javax.swing.JTextField txtIdContrato;
    // End of variables declaration//GEN-END:variables
}
